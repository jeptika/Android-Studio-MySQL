<?php
require("koneksi.php");

$response = array();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $nama = $_POST["nama"];
    $nim = $_POST["nim"];
    $angkatan = $_POST["angkatan"];
    $jurusan = $_POST["jurusan"];
    $prodi = $_POST["prodi"];

    $perintah = "INSERT INTO tbl_siswa (nama, nim, angkatan, jurusan, prodi) VALUES('$nama', '$nim', '$angkatan', '$jurusan', '$prodi')";
    $eksekusi = mysqli_query($konek, $perintah);
    $cek = mysqli_affected_rows($konek);

    if($cek>0){
        $response["kode"] = 1;
        $response["pesan"] = "Simpan Data Berhasil";
    }else{
        $response["kode"] = 0;
        $response["pesan"] = "Tidak Berhasil Menyimpan Data";
    }
}else{
    $response["kode"] = 0;
    $response["pesan"] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($konek);
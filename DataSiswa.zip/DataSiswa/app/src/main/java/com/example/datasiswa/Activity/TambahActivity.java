package com.example.datasiswa.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.datasiswa.API.APIRequestData;
import com.example.datasiswa.API.RetroServer;
import com.example.datasiswa.Model.ResponseModel;
import com.example.datasiswa.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TambahActivity extends AppCompatActivity {

    private EditText etNama, etNim, etAngkatan, etJurusan, etProdi;
    private Button btnSimpan;
    private String nama, nim, angkatan, jurusan, prodi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah);

        etNama = findViewById(R.id.et_nama);
        etNim = findViewById(R.id.et_nim);
        etAngkatan = findViewById(R.id.et_angkatan);
        etJurusan = findViewById(R.id.et_jurusan);
        etProdi = findViewById(R.id.et_prodi);
        btnSimpan = findViewById(R.id.btn_simpan);

        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nama = etNama.getText().toString();
                nim = etNim.getText().toString();
                angkatan = etAngkatan.getText().toString();
                jurusan = etJurusan.getText().toString();
                prodi = etProdi.getText().toString();

                if(nama.trim().equals("")){
                    etNama.setError("Nama harus diisi");
                }
                else if(nim.trim().equals("")){
                    etNim.setError("NIM harus diisi");
                }
                else if(angkatan.trim().equals("")){
                    etAngkatan.setError("Angkatan tahun berapa?");
                }
                else if(jurusan.trim().equals("")){
                    etJurusan.setError("Jurusan Apa?");
                }
                else if(prodi.trim().equals("")){
                    etProdi.setError("Prodi Apa?");
                }
                else{
                    createData();
                }
            }
        });
    }

    private void createData(){
        APIRequestData ardData = RetroServer.konekRetrofit().create(APIRequestData.class);
        Call<ResponseModel> simpanData = ardData.ardCreateData(nama, nim, angkatan, jurusan, prodi);

        simpanData.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                int kode = response.body().getKode();
                String pesan = response.body().getPesan();

                Toast.makeText(TambahActivity.this, "Kode : "+kode+" | Pesan : "+pesan, Toast.LENGTH_SHORT).show();
                finish();
            }

            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {
                Toast.makeText(TambahActivity.this, "Gagal Menghubungi | "+t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}